﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
    Vector2 dest = Vector2.zero;
    public float Speed = 4.0f;
    private Rigidbody2D rb;
    private bool MovingUp, MovingDown, MovingRight, MovingLeft;
    public Transform Portal1, Portal2, Portal3, Portal4;
    public int Flowers,Score,Lives;
    public Text FlowerCount, WinText,LoseText,ScoreText,LivesText;

    //boost
    public float boost;
    public GameObject enemyChaser;

    void Start()
    {
        Flowers = 0;
        Score = 0;
        Lives = 3;
        MovingUp = false;
        MovingDown = false;
        MovingRight = false;
        MovingLeft = false;
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        CheckInput();
        Move();

    }

    void CheckInput()
    {

        if (Input.GetKey(KeyCode.UpArrow))
        {
            MovingUp = true;
            MovingDown = false;
            MovingRight = false;
            MovingLeft = false;
            transform.localScale = new Vector3(1, 1, 0);
            transform.localRotation = Quaternion.Euler(0, 0, 90);
        }


        if (Input.GetKey(KeyCode.RightArrow))
        {
            MovingRight = true;
            MovingUp = false;
            MovingDown = false;
            MovingLeft = false;
            transform.localScale = new Vector3(1, 1, 0);
            transform.localRotation = Quaternion.Euler(0, 0, 0);

        }



        if (Input.GetKey(KeyCode.DownArrow))
        {
            MovingDown = true;
            MovingUp = false;
            MovingRight = false;
            MovingLeft = false;
            transform.localScale = new Vector3(1, 1, 0);
            transform.localRotation = Quaternion.Euler(0, 0, 270);
        }



        if (Input.GetKey(KeyCode.LeftArrow))
        {
            MovingLeft = true;
            MovingUp = false;
            MovingDown = false;
            MovingRight = false;
            transform.localScale = new Vector3(-1, 1, 0);
            transform.localRotation = Quaternion.Euler(0, 0, 0);
        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.tag == "Portal1")
        {
            rb.transform.position = new Vector3(9.5f, 3.5f, 0);
        }
        if (collision.collider.tag == "Portal2")
        {
            rb.transform.position = new Vector3(-6.5f, 3.5f, 0);
        }
        if (collision.collider.tag == "Portal3")
        {
            rb.transform.position = new Vector3(1.5f, 11.5f, 0);
        }
        if (collision.collider.tag == "Portal4")
        {
            rb.transform.position = new Vector3(1.5f, -4.5f, 0);
        }

        //if we decide to make more paroling enemies
        if (collision.collider.tag == "Enemy")
        {
            Lives = Lives - 1;
            rb.transform.position = new Vector3(1.5f, 3.5f, 0);
            SetAllText();
        }

        if (collision.collider.tag == "EnemyChaser")
        {
            if (boost > 0)
            {
                enemyChaser.transform.position = new Vector3(1.5f, 3.5f, 0);
                boost = boost - 1;
            } else 
            {   
                Lives = Lives - 1;
                rb.transform.position = new Vector3(1.5f, 3.5f, 0);
                SetAllText();
            }
        }

        //for second level
        if (collision.collider.tag == "EnemyTwo")
        {
            Lives = Lives - 1;
            //rb.transform.position = new Vector3(1.5f, 3.5f, 0);
            SetAllText();
        }
    }
    private void Move()
    {
        if (MovingUp == true)
            rb.transform.position = rb.transform.position + Vector3.up * Speed * Time.deltaTime;

        if (MovingRight == true)
            rb.transform.position = rb.transform.position + Vector3.right * Speed * Time.deltaTime;

        if (MovingDown == true)

            rb.transform.position = rb.transform.position + Vector3.down * Speed * Time.deltaTime;
        if (MovingLeft == true)

            rb.transform.position = rb.transform.position + Vector3.left * Speed * Time.deltaTime;


    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if ((other.gameObject.CompareTag("Flower")))
        {
            other.gameObject.SetActive(false);
            Flowers = Flowers + 1;
            Score = Score + 3;
            SetAllText();

        }

        if ((other.gameObject.CompareTag("BoosterFlower")))
        {
            other.gameObject.SetActive(false);
            boost = boost + 1;

        }

    }
    public void SetAllText()
    {
        FlowerCount.text = "" + Flowers.ToString();
        ScoreText.text = "" + Score.ToString();
        LivesText.text = "" + Lives.ToString();      
    }

}




